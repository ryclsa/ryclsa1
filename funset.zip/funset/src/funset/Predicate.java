package funset;

public interface Predicate {
	public boolean evaluate(int value);
}
