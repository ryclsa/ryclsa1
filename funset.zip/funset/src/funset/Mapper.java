package funset;

public interface Mapper {
	public int map(int value);
}
