package funset;

import java.util.Set;

public interface FunctionalSet extends Set<Integer> {
	public FunctionalSet union(FunctionalSet other);
	public FunctionalSet intersect(FunctionalSet other);
	public FunctionalSet filter(Predicate filter);
	public FunctionalSet map(Mapper mapper);
	public boolean contains(int value);
	public boolean contains(int value, Predicate condition);
	public int lowerBound();
	public int upperBound();
}
