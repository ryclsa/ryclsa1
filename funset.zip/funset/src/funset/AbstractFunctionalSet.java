package funset;

public abstract class AbstractFunctionalSet implements FunctionalSet {

	private final Predicate condition;
	private final int lowerBound;
	private final int upperBound;

	public AbstractFunctionalSet(final Predicate condition, final int lowerBound, final int upperBound) {
		super();
		this.condition = condition;
		this.lowerBound = lowerBound;
		this.upperBound = upperBound;
	}

	public AbstractFunctionalSet(final Predicate condition) {
		this(condition, Integer.MIN_VALUE, Integer.MAX_VALUE);
	}

	@Override
	public final boolean contains(final int value) {
		return (value >= lowerBound && value <= upperBound) && condition.evaluate(value);
	}

	@Override
	public final boolean contains(final Object object) {
		return (object != null && object instanceof Number) && contains(((Number) object).intValue());
	}

	@Override
	public final int lowerBound() {
		return lowerBound;
	}

	@Override
	public final int upperBound() {
		return upperBound;
	}

}
